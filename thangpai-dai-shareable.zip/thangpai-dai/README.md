# ทางไปได้ — Accessible Bangkok

เว็บต้นแบบที่ใช้แผนที่ OpenStreetMap, ค้นหาสถานที่ด้วย Nominatim และขอเส้นทางเดินจาก Valhalla public demo

## ทดลองในเครื่อง
เปิด `index.html` ผ่านเว็บเซิร์ฟเวอร์หรือโฮสต์ static site (บางเบราว์เซอร์จำกัด geolocation เมื่อเปิดเป็น file://)

## เผยแพร่ฟรีด้วย GitHub Pages
1. สร้าง repository ใหม่แบบ Public ใน GitHub
2. อัปโหลด `index.html` ไปที่ root ของ repository
3. ไปที่ Settings → Pages
4. ใน Build and deployment เลือก Deploy from a branch, เลือก `main` และ `/(root)` แล้ว Save
5. รอการ deploy จากนั้นกด Visit site เพื่อคัดลอก URL มาแชร์

GitHub Pages: https://docs.github.com/en/pages/quickstart

## ข้อจำกัดสำคัญ
- เส้นทางเดินมาจาก Valhalla public demo และอาจไม่พร้อมให้บริการตลอดเวลา
- เส้นทางเดินไม่ได้รับรองว่ารถเข็นผ่านได้ทุกช่วง ตัวกรองทางลาดยังเป็นป้ายแนวคิด ไม่ได้เปลี่ยนการคำนวณเส้นทาง
- รายงานถูกเก็บใน localStorage ของเบราว์เซอร์เครื่องนั้นเท่านั้น ไม่ได้แชร์กับคนอื่น และหายได้เมื่อล้างข้อมูลเบราว์เซอร์
- ก่อนเปิดใช้สาธารณะอย่างจริงจัง ต้องเพิ่ม backend/database ที่มีการตรวจสอบรายงาน, วันเวลาปรับปรุง, การกลั่นกรองข้อมูล และนโยบายความเป็นส่วนตัว
- บริการ Nominatim, OpenStreetMap tiles และ Valhalla เป็นบริการสาธารณะ มีข้อจำกัดการใช้งานและนโยบายของผู้ให้บริการ
